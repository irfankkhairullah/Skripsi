# TFIDF

## Implementation of TF-IDF from scratch in Python

#### Term Frequency: This summarizes how often a given word appears within a document.
#### Inverse Document Frequency: This downscales words that appear a lot across documents.

#### The blog explaning the code https://medium.freecodecamp.org/how-to-process-textual-data-using-tf-idf-in-python-cd2bbc0a94a3
