# twitter-sentiment
Sentiment analysis of tweets using knn
